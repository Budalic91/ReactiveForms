#Changes made to the course since its release:
- November 6, 2018 - Updated the course from Angular v2 to Angular v7 including an update to the Angular CLI, Bootstrap 4, and FontAwesome. For details on the list of course changes, see: https://blogs.msmvps.com/deborahk/angular-reactive-forms-course-update-for-v7/

#Changes made to the project files since its release:
- November 6, 2018 - Updated the course files from Angular v2 to Angular v7 including an update to the Angular CLI, Bootstrap 4, and FontAwesome.
- November 6, 2018 - Removed the xxx-Updated files as the code is currently up to date.

- July 27, 2018 - APM-Updated were modified to Angular v6, RxJS v6, Bootrap v4, and FontAwesome. The changes include moving the code from systemjs to the Angular CLI and all of the new style classes for Bootrap 4.
- July 27, 2018 - Demo-Start-Updated and Demo-Final-Updated were modified to Angular v6 and Bootrap v4. The changes include moving the code from systemjs to the Angular CLI and all of the new style classes for Bootrap 4.

- March 24, 2017 - APM-Updated was added. This is an update to the sample application for Angular version 4. The changes include modifications to the boilerplate files and the addition of an src folder to make these files compatible with the current version of the Angular Quick Start files.
- March 24, 2017 - Demo-Start-Updated and Demo-Final-Updated were added. These are an update to the demo application for Angular version 4. The changes include modifications to the boilerplate files and the addition of an src folder to make these files compatible with the current version of the Angular Quick Start files.
